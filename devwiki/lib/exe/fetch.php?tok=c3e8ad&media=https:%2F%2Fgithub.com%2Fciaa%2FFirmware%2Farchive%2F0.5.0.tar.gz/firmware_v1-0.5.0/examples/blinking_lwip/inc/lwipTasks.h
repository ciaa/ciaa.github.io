/*
 * lwipTasks.h
 *
 *  Created on: Sep 1, 2014
 *      Author: pablo
 */

#ifndef LWIPTASKS_H_
#define LWIPTASKS_H_


void ciaaLWIP_start(void);
void ciaaLWIP_loop(void);


#endif /* LWIPTASKS_H_ */
