#define CRP_NO_CRP          0xFFFFFFFF

__attribute__ ((used,section(".crp"))) const unsigned int CRP_WORD = CRP_NO_CRP ;

